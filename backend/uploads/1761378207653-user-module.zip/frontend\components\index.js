import UserManager from './UserManager';

export { UserManager };
export default UserManager;